package com.substring.irctc.annotations;

public @interface ValidPassword
{

}
