package com.substring.irctc.dto;

public record LoginRequest(
        String username,
        String password
) {
}
