package com.substring.irctc.config;

public class AppConstants {

    public static final String BASE_URL="http://localhost:8080";

    public static final String DEFAULT_PAGE_SIZE="10";
    public static final String DEFAULT_PAGE="0";
}
