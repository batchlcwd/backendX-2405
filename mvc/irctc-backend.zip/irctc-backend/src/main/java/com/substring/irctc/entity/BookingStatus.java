package com.substring.irctc.entity;

public enum BookingStatus {
    PENDING, CONFIRMED, CANCELLED
}
