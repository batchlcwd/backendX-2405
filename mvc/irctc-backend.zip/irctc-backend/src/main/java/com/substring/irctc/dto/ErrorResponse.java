package com.substring.irctc.dto;

public record ErrorResponse(String message, String code, boolean success)
{

}
