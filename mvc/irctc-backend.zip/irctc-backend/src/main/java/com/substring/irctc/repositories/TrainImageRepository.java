package com.substring.irctc.repositories;

import com.substring.irctc.entity.TrainImage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TrainImageRepository extends JpaRepository<TrainImage,Long> {
}
