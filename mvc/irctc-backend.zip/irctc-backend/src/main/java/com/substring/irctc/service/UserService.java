package com.substring.irctc.service;

import com.substring.irctc.dto.UserDto;

public interface UserService {


    public UserDto registerUser(UserDto userDto);


}
