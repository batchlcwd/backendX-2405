package com.substring.irctc.entity;

public enum PaymentStatus {
    PENDING,PAID, FAILED, REFUNDED
}
