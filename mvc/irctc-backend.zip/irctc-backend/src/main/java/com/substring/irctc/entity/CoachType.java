package com.substring.irctc.entity;

public enum CoachType {
    AC, SLEEPER, GENERAL
}
